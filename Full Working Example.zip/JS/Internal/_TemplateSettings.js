_.templateSettings = {
	interpolate: /\{\{([\s\S]+?)\}\}/g,
	evaluate: /\{\%([\s\S]+?)\}\}/g
};